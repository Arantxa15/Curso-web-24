function contenedor(mensaje) {
    alert('Has pulsado ' + mensaje);
}