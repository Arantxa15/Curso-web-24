let numero = prompt('Ingresa un número');

